# Proyecto final 

## Análisis de datos RNA-Masivo

En el laboratorio de metabolismo energético de la UNAM juriquilla se trabaja con yodo molecular para la prevenir la iniciación y progresión de diversos tipos de cáncer . En el presente proyecto se analiza los datos obtenidos en el articulo Nutrients 2019, 11, 1623; doi:10.3390/nu11071623

En dicho articulo se realiza un análisis de expresión diferencial por transcriptomica donde se analizan muestras de pacientes con cáncer de mama  tratados solo con yodo molecular o en combinación con la terapia neoadjuvante 5-fluroacil/epirubicin/ciclofosfamida o taxotere/epirubidicin (FEC/TE) en mujeres con cancer de mama en etapa temprana (Etapa II) y etapa avanzada (Etapa III)

## Objetivos: Analizar la calidad de las secuencias generadas en el articulo
#             Analizar la expresión diferencial de genes en los diferentes tratamientos

Código Usado

Dado que los archivos son muy pesados crearemos un directorio en el servidor para trabajar con ellos.
Para conectarnos al servidor usamos 

```
ssh alumno23@10.147.17.33
```

Una vez ahí usamos pwd para saber en donde nos encontramos

```
(base) -bash-4.4$ pwd
/home/alumno23
```

Posteriormente creamos  una carpeta y subcarpetas de trabajo

```
mkdir analisis_edgar

mkdir control2

mkdir resultadosgeneral

mkdir tratamientoyodo
```

Primero pasamos los archivos de RNA-seq de la pc al servidor  con el comando SCP para poder trabajar con ellos, para esto usamos lo siguiente

```
scp /home/ejuvera/rna_seq/*.gz  alumno23@10.147.17.33:/home/alumno23/analisis_edgar/control2
alumno23@10.147.17.33's password: RqEmACZhuh
```

![image-20211114140938585](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114140938585.png)

Después descomprimimos los archivos usando

```
gunzip *gz
```

![image-20211114141750747](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114141750747.png)

Hacemos lo mismo para cargar los archivos de la muestra con el tratamiento de con Yodo Molecular

![image-20211114142115004](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114142115004.png)

De esta manera ya podemos visualizar la información de los archivos 

```
head -4 T7_GTGAAA_L001_R1_001.fastq
```

![image-20211114142853045](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114142853045.png)

Ahora analizamos la calidad de la secuenciación usando el programa fastqc

```
fastqc *.fastq *
```

Lo cual después procesar los archivos nos generara unos archivos de salida .html y .zip

![image-20211114145402381](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114145402381.png)

Creamos un nuevo directorio y movemos los archivos html y .zip

```
mkdir resultadostratamiento

mv *.html resultadostratamiento

mv *.zip   resultadostratamiento
```

![image-20211114150206702](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114150206702.png)

Para poder visualizar los archivos es necesario copiemos los archivos a nuestra computadora local, para esto necesitamos cambiar los permisos del archivo usando

```
chmod +x *html
```

Copiamos los archivos del grupo control y de la muestra con tratamiento

```
scp alumno23@10.147.17.33:/home/alumno23/analisis_edgar/tratamientoyodo/resultadostratamiento/*.html /home/ejuvera/rna_seq/fastqc_html/
```

![image-20211114151240442](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114151240442.png)

```
scp alumno23@10.147.17.33:/home/alumno23/analisis_edgar/control2/resultados/*.html /home/ejuvera/rna_seq/fastqc_html/
```

![image-20211114153052102](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114153052102.png)

Ahora podemos visualizar la calidad de las lecturas abriendo los archivos html

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211116130203379.png" alt="image-20211116130203379" style="zoom:80%;" />

Ejemplo:

![image-20211114163500644](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114163500644.png)

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114163523444.png" alt="image-20211114163523444" style="zoom:80%;" />

Una vez analizado la calidad de las lecturas podemos hacer una limpieza usando trimmomatic

Para esto necesitamos el archivo de NexteraPE en la carpeta donde se encuentran nuestros archivos

Una vez teniendo los archivos necesitamos indicarle los archivos pareados de entrada a trimmomatic asi como indicarle los archivos de salida

Ejemplo

```
trimmomatic PE T7_GTGAAA_L001_R1_001.fastq T7_GTGAAA_L001_R1_002.fastq T7_GTGAAA_L001_R1_001.trim.fastq.gz T7_GTGAAA_L001_R1_002.trim.fastq.gz T7_GTGAAA_L001_R1_2un.trim.fastq.gz SLIDINGWINDOW:4:20 MINLEN:25 ILLUMINACLIP:NexteraPE-PE.fa:2:40:15
```

Esto nos generara dos archivos nuevos de salida

![image-20211116123017307](/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211116123017307.png)

Para descomprimir los archivos anteriormente creados usamos el siguiente loop para que descomprima todos los archivos.

```
$ for filename in *.zip
> do
> unzip $filename
> done
```

Este comando va descomprimir los archivos .zip y creara nuevos directorios con subdirectorios para cada una uno de los archivos para almacenar los archivos de salida producidos por FastQC

Para cada una de las muestras se crea un archivo llamado summary.txt que nos da información sobre los análisis que paso o fallo cada muestra 

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114163850434.png" alt="image-20211114163850434" style="zoom:80%;" />

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114164448830.png" alt="image-20211114164448830" style="zoom:80%;" />

Ahora juntamos el análisis de todas las muestras y creando un nuevo archivo usando

```
(base) -bash-4.4$ cat */summary.txt > fastqc_summaries.txt
```

Por ultimo analizamos cuantas pruebas fallo cada una de las lecturas del grupo control con el siguiente comando

```
(base) -bash-4.4$ grep "FAIL" fastqc_summaries.tx |cut -f3| uniq -c
(base) -bash-4.4$ grep "FAIL" fastqc_summariestratamiento.tx |cut -f3| uniq -c

```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114165143392.png" alt="image-20211114165143392" style="zoom:80%;" />

Repetimos lo mismo para la muestra con tratamiento de yodo

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211114165914574.png" alt="image-20211114165914574" style="zoom:80%;" />

## Análisis de expresión diferencial en R

Análisis de muestras grupo control

Cáncer de mama sin tratamiento de yodo

Limpiar variables

```R
rm(list=ls())
```

Cargar paquetes

```R
library('limma')
library('edgeR')
```

#Leer archivo de muestras

```R
targets <- readTargets()
targets
```

```R
##          Lane Treatment    Label`

## `Sano1       1   Control    Sano1`

## `Sano2       2   Control    Sano2`

## `Placebo1    3     Tumor Placebo1`

## `Placebo2    4     Tumor Placebo2
```

#Cargar archivo de conteos

```R
x <- read.delim("LISTO-sano-cancer.txt", sep=' ', row.names=1, header=FALSE, stringsAsFactors=FALSE)
head(x)
```

```R
##          V2 V3 V4  V5

## 0R7H2P    0  0  0   0

## 5S_rRNA   3  6  4   9

## 7SK      68 34 75 135

## A1BG      8  7  6   5

## A1BG-AS1 74 53 40  46

## A1CF      0  0  0   1
```

#Poner conteos e información en un objeto de DGEList

```R
y <- DGEList(counts=x[,1:4], group=targets$Treatment)
colnames(y) <- targets$Label
```

#Conocer dimensión del objeto creado

```R
dim(y) 
```

```
## [1] 56242     4
```

#Filtrado: Filtramos los genes con menor expresión, dejando los genes que se exoresan a un nivel razonable en al menos una condición de tratamiento. Dado que el grupo tamaño de grupo mas pequeño es 3. conservamos genes que logren al mnos una cuenta por millón(cpm) en al menos 3 muestras                                  

```R
keep <- rowSums(cpm(y)>1) >= 2 
y <- y[keep,]
dim(y)
```

```
## [1] 18730     4
```

#Re-calcular tamaño librerias:

```R
y$samples$lib.size <- colSums(y$counts)
```

#Normalizando
#Calcular tamaño libreria efectiva usando normalización TMM

```R
y <- calcNormFactors(y)
y$samples
```

```
##            group lib.size norm.factors

## Sano1    Control 16911519    0.9806803

## Sano2    Control  9031533    0.9198342

## Placebo1   Tumor 14886795    1.0485584

## Placebo2   Tumor 21326450    1.0572321
```

#Data Exploration
#El grafico MDS muestra la distancia en terminos del coeficiente de variación biológica entre muestras

```R
pdf('MDSplotsano-cancer.pdf')
plotMDS(y)
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211117142726173.png" alt="image-20211117142726173" style="zoom:67%;" />

#Estimar dispersión
#La dispersión común estima el BCV general del conjunto de datos, promediado sobre todos los genes:

```R
y <- estimateCommonDisp(y, verbose=TRUE)
```

```R
## Disp = 0.0114 , BCV = 0.1068
```

#Dispersión gen especificas

```R
y <- estimateTagwiseDisp(y)
```

#Graficar las dispersiones estimadas

```R
pdf('BCVplotsano-cancer.pdf')
plotBCV(y)
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211117142643396.png" alt="image-20211117142643396" style="zoom:80%;" />

#Expresión diferencial
#Calcular pruebas exactas de genes para la expresión diferencial entre los tratamientos mm9 y mm10

```R
et <- exactTest(y)
top <- topTags(et)
top
```

```
## Comparison of groups:  Tumor-Control 

##              logFC    logCPM        PValue           FDR

## DLK1     10.681254 10.601075  0.000000e+00  0.000000e+00

## TFAP2B    7.255645  8.394768 1.167163e-286 1.093048e-282

## A2ML1    -6.703960  8.156610 5.185714e-258 3.237614e-254

## KRT6A    -8.960377  6.177319 2.401545e-243 1.124523e-239

## DIO2      5.807954  8.345666 5.354803e-233 2.005909e-229

## MSLN     -8.644050  8.810463 6.212931e-220 1.939470e-216

## SLC6A20  -7.997653  5.831845 3.675494e-214 9.834571e-211

## GPR88     8.225633  6.457432 2.312590e-208 5.414352e-205

## SMR3B     7.230134  6.604269 6.837770e-207 1.423016e-203

## ATP6V1C2 -5.703385  7.518377 1.196012e-204 2.240130e-201
```

#Valores cpm individuales de los genes top

```R
cpm(y)[rownames(top), ]
```


#Graficar log-fold-changes, resaltando los genes expresados diferencialmente

```R
pdf('logFC-sano-cancer.pdf')
detags <- rownames(y)[as.logical(de)]
plotSmear(et, de.tags=detags)
abline(h=c(-1, 1), col="blue")
dev.off()
```
<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211117142611193.png" alt="image-20211117142611193" style="zoom:80%;" />

## Análisis de muestras con Yodo molecular

Cargar paquetes

```R
library('limma')
library('edgeR')
```

Limpiar variables

```R
rm(list=ls())
```

Cargar archivo de muestras

```R
targets <- readTargets(file="targets-cancer-yodo.txt")
targets
```

```
##         Lane Treatment   Label

## Cancer1    1    Cancer Cancer1

## Cancer2    2    Cancer Cancer2

## Iodine1    3    Iodine Iodine1

## Iodine2    4    Iodine Iodine2
```

Cargar archivo de conteos

```R
x <- read.delim("LISTO-cancer-yodo.txt", sep=' ', row.names=1, header=FALSE, stringsAsFactors=FALSE)
head(x)
```

```
##          V2  V3  V4  V5

## 0R7H2P    0   0   0   0

## 5S_rRNA   4   9   4   2

## 7SK      75 135 168 185

## A1BG      6   5   5   0

## A1BG-AS1 40  46  13  15

## A1CF      0   1   3   3
```

#Poner las cuentas e información en un objeto DGElist

```R
y <- DGEList(counts=x[,1:4], group=targets$Treatment)
colnames(y) <- targets$Label
dim(y)
```

```
## [1] 56242     4
```

Filtrado: Filtramos los genes con menor expresión, dejando los genes que se expresan a un nivel razonable en al menos una condición de tratamiento. Dado que el grupo tamaño de grupo mas pequeño es 3. conservamos genes que logren almenos una cuenta por millón(cpm) en al menos 3 muestras 

```R
keep <- rowSums(cpm(y)>1) >= 2
y <- y[keep,]
dim(y)
```

```
## [1] 18922     4
```

#Re-calcular tamaño librerias:

```R
y$samples$lib.size <- colSums(y$counts)
```

#Normalizando
#Calcular tamaño libreria efectiva usando normalización TMM

```R
y <- calcNormFactors(y)
y$samples
```

```
##          group lib.size norm.factors

## Cancer1 Cancer 14888345    1.0163288

## Cancer2 Cancer 21329092    1.0248228

## Iodine1 Iodine 13310581    0.9776339

## Iodine2 Iodine 14949330    0.9820662
```

#Data Exploration
#El grafico MDS muestra la distancia en terminos del coeficiente de variación biológica entre muestras

```R
pdf('MDSplotcancer-yodo.pdf')
plotMDS(y)
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211118105110138.png" alt="image-20211118105110138" style="zoom:80%;" />

#Estimar dispersión
#La dispersión común estima el BCV general del conjunto de datos, promediado sobre todos los genes:

```R
y <- estimateCommonDisp(y, verbose=TRUE)
```

```
## Disp = 0.0053 , BCV = 0.0728
```

#Dispersión gen especificas

```R
y <- estimateTagwiseDisp(y)
```

#Graficar las dispersiones estimadas

```R
pdf('BCVplotcancer-yodo.pdf')
plotBCV(y)
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211118105136156.png" alt="image-20211118105136156" style="zoom:80%;" />

#Expresión diferencial
#Calcular pruebas exactas de genes para la expresión diferencial entre los tratamientos mm9 y mm10

```R
et <- exactTest(y)
top <- topTags(et)
top
```

```
## Comparison of groups:  Iodine-Cancer 

##             logFC    logCPM        PValue           FDR

## SMR3B   -9.203518  6.639745  0.000000e+00  0.000000e+00

## S100A7A  9.117824  5.527879  0.000000e+00  0.000000e+00

## S100A7   8.761642  6.731576  0.000000e+00  0.000000e+00

## DLK1    -6.047548 10.666319  0.000000e+00  0.000000e+00

## S100A8   5.780575  7.202485  0.000000e+00  0.000000e+00

## A2ML1    5.359569  6.865422  0.000000e+00  0.000000e+00

## GABRP   -5.100289  7.414772  0.000000e+00  0.000000e+00

## FGFR2   -4.968576  8.232310  0.000000e+00  0.000000e+00

## CALML5   4.683675  9.077925  0.000000e+00  0.000000e+00

## FABP7    4.844256  7.472598 1.001825e-311 1.895653e-308
```

#Valores cpm individuales de los genes top

```R
cpm(y)[rownames(top), ]
```

#EL número total de genes DE a 5% FDR es dado por

```R
summary(de <- decideTestsDGE(et))
```

#Graficar log-fold-changes, resaltando los genes expresados diferencialmente

```R
pdf('logFCcancer-yodo.pdf')
detags <- rownames(y)[as.logical(de)]
plotSmear(et, de.tags=detags)
abline(h=c(-1, 1), col="blue")
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211118105238779.png" alt="image-20211118105238779" style="zoom:90%;" />