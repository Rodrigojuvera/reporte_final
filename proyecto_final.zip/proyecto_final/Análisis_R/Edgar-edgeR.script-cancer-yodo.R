## Análisis de muestras con Yodo molecular

Cargar paquetes

```R
library('limma')
library('edgeR')
```

Limpiar variables

```R
rm(list=ls())
```

Cargar archivo de muestras

```R
targets <- readTargets(file="targets-cancer-yodo.txt")
targets
```

```
##         Lane Treatment   Label

## Cancer1    1    Cancer Cancer1

## Cancer2    2    Cancer Cancer2

## Iodine1    3    Iodine Iodine1

## Iodine2    4    Iodine Iodine2
```

Cargar archivo de conteos

```R
x <- read.delim("LISTO-cancer-yodo.txt", sep=' ', row.names=1, header=FALSE, stringsAsFactors=FALSE)
head(x)
```

```
##          V2  V3  V4  V5

## 0R7H2P    0   0   0   0

## 5S_rRNA   4   9   4   2

## 7SK      75 135 168 185

## A1BG      6   5   5   0

## A1BG-AS1 40  46  13  15

## A1CF      0   1   3   3
```

#Poner las cuentas e información en un objeto DGElist

```R
y <- DGEList(counts=x[,1:4], group=targets$Treatment)
colnames(y) <- targets$Label
dim(y)
```

```
## [1] 56242     4
```

Filtrado: Filtramos los genes con menor expresión, dejando los genes que se exoresan a un nivel razonable en al menos una condición de tratamiento. Dado que el grupo tamaño de grupo mas pequeño es 3. conservamos genes que logren al mnos una cuenta por millón(cpm) en al menos 3 muestras 

```R
keep <- rowSums(cpm(y)>1) >= 2
y <- y[keep,]
dim(y)
```

```
## [1] 18922     4
```

#Re-calcular tamaño librerias:

```R
y$samples$lib.size <- colSums(y$counts)
```

#Normalizando
#Calcular tamaño libreria efectiva usando normalización TMM

```R
y <- calcNormFactors(y)
y$samples
```

```
##          group lib.size norm.factors

## Cancer1 Cancer 14888345    1.0163288

## Cancer2 Cancer 21329092    1.0248228

## Iodine1 Iodine 13310581    0.9776339

## Iodine2 Iodine 14949330    0.9820662
```

#Data Exploration
#El grafico MDS muestra la distancia en terminos del coeficiente de variación biológica entre muestras

```R
pdf('MDSplotcancer-yodo.pdf')
plotMDS(y)
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211118105110138.png" alt="image-20211118105110138" style="zoom:80%;" />

#Estimar dispersión
#La dispersión común estima el BCV general del conjunto de datos, promediado sobre todos los genes:

```R
y <- estimateCommonDisp(y, verbose=TRUE)
```

```
## Disp = 0.0053 , BCV = 0.0728
```

#Dispersión gen especificas

```R
y <- estimateTagwiseDisp(y)
```

#Graficar las dispersiones estimadas

```R
pdf('BCVplotcancer-yodo.pdf')
plotBCV(y)
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211118105136156.png" alt="image-20211118105136156" style="zoom:80%;" />

#Expresión diferencial
#Calcular pruebas exactas de genes para la expresión diferencial entre los tratamientos mm9 y mm10

```R
et <- exactTest(y)
top <- topTags(et)
top
```

```
## Comparison of groups:  Iodine-Cancer 

##             logFC    logCPM        PValue           FDR

## SMR3B   -9.203518  6.639745  0.000000e+00  0.000000e+00

## S100A7A  9.117824  5.527879  0.000000e+00  0.000000e+00

## S100A7   8.761642  6.731576  0.000000e+00  0.000000e+00

## DLK1    -6.047548 10.666319  0.000000e+00  0.000000e+00

## S100A8   5.780575  7.202485  0.000000e+00  0.000000e+00

## A2ML1    5.359569  6.865422  0.000000e+00  0.000000e+00

## GABRP   -5.100289  7.414772  0.000000e+00  0.000000e+00

## FGFR2   -4.968576  8.232310  0.000000e+00  0.000000e+00

## CALML5   4.683675  9.077925  0.000000e+00  0.000000e+00

## FABP7    4.844256  7.472598 1.001825e-311 1.895653e-308
```

#Valores cpm individuales de los genes top

```R
cpm(y)[rownames(top), ]
```

#EL número total de genes DE a 5% FDR es dado por

```R
summary(de <- decideTestsDGE(et))
```

#Graficar log-fold-changes, resaltando los genes expresados diferencialmente

```R
pdf('logFCcancer-yodo.pdf')
detags <- rownames(y)[as.logical(de)]
plotSmear(et, de.tags=detags)
abline(h=c(-1, 1), col="blue")
dev.off()
```

<img src="/home/ejuvera/snap/typora/42/.config/Typora/typora-user-images/image-20211118105238779.png" alt="image-20211118105238779" style="zoom:80%;" />

