## Análisis de expresión diferencial en R

#Análisis de muestras grupo control

#Cáncer de mama sin tratamiento de yodo

#Limpiar variables
rm(list=ls())

#Cargar paquetes
library('limma')
library('edgeR')
#Leer archivo de muestras
targets <- readTargets()
targets

#Cargar archivo de conteos
x <- read.delim("LISTO-sano-cancer.txt", sep=' ', row.names=1, header=FALSE, stringsAsFactors=FALSE)
head(x)

#Poner cuentas e información en un objeto de DGEList
y <- DGEList(counts=x[,1:4], group=targets$Treatment)
colnames(y) <- targets$Label
#Conocer dimensión del objeto creado
dim(y) 

#Filtrado: Filtramos los genes con menor expresión, dejando los genes que se exoresan a un nivel razonable en al menos una condición de tratamiento. Dado que el grupo tamaño de grupo mas pequeño es 3. conservamos genes que logren al mnos una cuenta por millón(cpm) en al menos 3 muestras                                      
keep <- rowSums(cpm(y)>1) >= 2 
y <- y[keep,]
dim(y)


#Re-calcular tamaño librerias:
y$samples$lib.size <- colSums(y$counts)

#Normalizando
#Calcular tamaño libreria efectiva usando normalización TMM
y <- calcNormFactors(y)
y$samples

#Data Exploration
#El grafico MDS muestra la distancia en terminos del coeficiente de variación biológica entre muestras
pdf('MDSplotsano-cancer.pdf')
plotMDS(y)
dev.off()

#Estimar dispersión
#La dispersión común estima el BCV general del conjunto de datos, promediado sobre todos los genes:
y <- estimateCommonDisp(y, verbose=TRUE)

#Dispersión gen especificas
y <- estimateTagwiseDisp(y)

#Graficar las dispersiones estimadas
pdf('BCVplotsano-cancer.pdf')
plotBCV(y)
dev.off()

#Expresión diferencial
#Calcular pruebas exactas de genes para la expresión diferencial entre los tratamientos mm9 y mm10
et <- exactTest(y)
top <- topTags(et)
top

#Valores cpm individuales de los genes top
cpm(y)[rownames(top), ]

#EL número total de genes DE a 5% FDR es dado por
summary(de <- decideTestsDGE(et))

#Graficar log-fold-changes, resaltando los genes expresados diferencialmente
pdf('logFC-sano-cancer.pdf')
detags <- rownames(y)[as.logical(de)]
plotSmear(et, de.tags=detags)
abline(h=c(-1, 1), col="blue")
dev.off()

#Para la lista de todos los genes y FDR.
tab<-topTags(et, n=nrow(y))
write.table(tab, file="FDR-sano-cancer.txt", sep=" ")
